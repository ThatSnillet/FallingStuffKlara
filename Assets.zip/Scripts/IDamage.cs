public interface IDamage
{
    void OnDamage(int dmg);
}
